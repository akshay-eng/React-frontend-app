const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const PORT = 8003;

// Middleware
app.use(cors());
app.use(express.json()); // Ensure request body is parsed as JSON

// Proxy route
app.post('/executeAPIService/', async (req, res) => {
    try {
        console.log('Received request from Frontend:', JSON.stringify(req.body, null, 2));

        const requestBody = req.body.updatedServiceObj || req.body;
        console.log('Forwarding request to Backend with body:', JSON.stringify(requestBody, null, 2));

        const response = await axios.post('http://172.17.204.4:8003/executeAPIService/', requestBody, {
            headers: { 'Content-Type': 'application/json' }
        });

        console.log('Response from Backend:', JSON.stringify(response.data, null, 2));

        res.status(response.status).json(response.data);
    } catch (error) {
        console.error('Error forwarding request:', error.response?.data || error.message);
        res.status(error.response?.status || 500).json({ error: error.response?.data || 'Failed to reach backend' });
    }
});



// Start server
app.listen(PORT, () => {
    console.log(`Proxy server is running on http://localhost:${PORT}`);
});
