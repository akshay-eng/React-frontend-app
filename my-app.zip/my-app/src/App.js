import React, { useState, useCallback } from 'react';
import { WebChatContainer, setEnableDebug } from '@ibm-watson/assistant-web-chat-react';

setEnableDebug(true);

const webChatOptions = {
  integrationID: '142c6af4-9a36-4ebd-822b-9cd1909284bc',
  region: 'dev',
  serviceInstanceID: '00000000-0000-0000-1732-881097915877',
  cloudPrivateHostURL: 'https://cpd-cpd.apps.watsonx.sdxtest.local/assistant/cpd-wa/integrations',
};

function App() {
  const [instance, setInstance] = useState(null);

  // Store the instance when it's available
  const onBeforeRender = useCallback((webChatInstance) => {
    setInstance(webChatInstance);
  }, []);

  // Function to handle form submission and send the message
  function handleCustomSubmit(api, apiInputParams, description) {
    const updatedInputArray = apiInputParams.map((element) => {
      const value = document.getElementById(element.name)?.value.trim();
      return { name: element.name, value: value || '' };
    });

    const updatedServiceObj = {
      api: api, // Dynamically setting API from Watson response
      payload: updatedInputArray,
      description: description,
    };

    const message = {
      context: {
        skills: {
          'actions skill': {
            skill_variables: {
              service_object: updatedServiceObj,
            },
          },
        },
      },
      input: {
        text: 'CALL_THE_API',
      },
      history: {
        label: 'Executing the service...',
      },
    };

    // Check if the instance is available and send the message
    if (instance) {
      console.log('Sending message:', JSON.stringify(message));
      instance.send(message);
    } else {
      console.error('Instance not initialized');
    }
  }

  // Rendering the dynamic form based on user-defined responses
  function renderUserDefinedResponse(event) {
    if (event.data.message.user_defined && event.data.message.user_defined.user_defined_type === 'show_input_form') {
      const { fullMessage } = event.data;
      const serviceObj = fullMessage.context.skills['actions skill'].skill_variables.service_selected.item;
      const apiInputParams = serviceObj.payload;
      const api = serviceObj.api; // Extract API dynamically
      const description = serviceObj.description;

      return (
        <div>
          <p>Please fill the following fields:</p>
          {apiInputParams.map((element) => (
            <div key={element.name} style={{ margin: '8px 0' }}>
              <label style={{ fontWeight: 'bold' }}>{element.name}:</label>
              <input
                type={element.name.toLowerCase().includes('password') ? 'password' : 'text'}
                id={element.name}
                placeholder={`Enter ${element.name}`}
                style={{ margin: '5px', padding: '5px', width: '200px' }}
              />
            </div>
          ))}
          <div style={{ marginTop: '10px' }}>
            <button
              style={{ padding: '8px 12px', backgroundColor: '#007bff', color: '#fff', border: 'none', borderRadius: '4px' }}
              onClick={() => handleCustomSubmit(api, apiInputParams, description)}
            >
              Submit
            </button>
          </div>
        </div>
      );
    }
  }

  return (
    <div>
      <h2>Custom IBM Watson Assistant Web Chat</h2>
      <WebChatContainer
        config={webChatOptions}
        onBeforeRender={onBeforeRender} // Capture the instance here
        renderUserDefinedResponse={renderUserDefinedResponse}
      />
    </div>
  );
}

export default App;
